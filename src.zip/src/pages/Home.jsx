import { useState, useEffect } from "react";
import { toast } from "react-toastify";
import {
  getTopHeadlines,
  getCategoryNews,
  searchNews,
} from "../services/apiService";
import Loader from "../components/Loader";
import NewsCard from "../components/NewsCard";
import Category from "../components/Category";
import SearchBar from "../components/SearchBar";

function Home() {
  const [newsData, setNewsData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [category, setCategory] = useState("general");
  const [search, setSearch] = useState("");
  const [isSearching, setIsSearching] = useState(false);

  useEffect(() => {
    fetchNews();
  }, [category]);

  const fetchNews = async () => {
    try {
      setLoading(true);
      let data;
      if (category === "general") {
        data = await getTopHeadlines();
      } else {
        data = await getCategoryNews(category);
      }
      console.log(data);
      setNewsData(data);
    } catch (error) {
      console.log(error);
      toast.error("Something Went Wrong");
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async () => {
    if (search.trim().length === 0) {
      toast.error("Please enter something to search");
      return;
    }
    try {
      setLoading(true);
      setIsSearching(true);

      const data = await searchNews(search);
      setNewsData(data);
    } catch (error) {
      console.log(error);
      toast.error("Search Failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto py-10 px-6">
      <div className="bg-linear-to-r from-red-800 to-red-600 text-white rounded-xl p-10">
        <h1 className="text-5xl font-bold">Stay Updated With Latest News</h1>
        <p className="mt-5 text-lg">
          Read the latest news from around the world.
        </p>
        <button className="mt-6 bg-white text-red-600 text-lg px-6 py-3 rounded-lg font-semibold">
          Explore News
        </button>
      </div>

      <SearchBar
        search={search}
        setSearch={setSearch}
        handleSearch={handleSearch}
      />

      <Category category={category} setCategory={setCategory} />

      <h2 className="text-3xl font-bold mb-8 capitalize">
        {" "}
        {category === "general" ? "Top Headlines" : `${category} News`}
      </h2>

      {loading ? (
        <Loader />
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {newsData.map((n, index) => (
            <NewsCard key={index} news={n} />
          ))}
        </div>
      )}
    </div>
  );
}

export default Home;
